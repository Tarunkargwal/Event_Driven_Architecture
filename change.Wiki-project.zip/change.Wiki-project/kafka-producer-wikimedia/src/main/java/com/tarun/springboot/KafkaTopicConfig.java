package com.tarun.springboot;

import java.beans.BeanProperty;

@Configration
public class KafkaTopicConfig {
    @Bean
    public NewTopic topic(){
        return TopicBuilder.name("wikimedia_recent").build();
    }
}
