package com.tarun.springboot;

import java.lang.reflect.Method;

public class WikiMediaChangesHandler implements EventHandler {
    // implements all the message
    //
    private KafkaTemplate<String,String> kafkaTemplate;
    private String topic;

    public WikiMediaChangesHandler(KafkaTemplate<String, String> kafkaTemplate, String topic) {
        this.kafkaTemplate = kafkaTemplate;
        this.topic = topic;
    }

    // onmessage
    @Override
    public void onMessage(String s, MessageEvent messageEvent) throws Exception{
        // Loggger Statement

        kafkaTemplate.send(topic, messageEvent.getData());
    }
}
