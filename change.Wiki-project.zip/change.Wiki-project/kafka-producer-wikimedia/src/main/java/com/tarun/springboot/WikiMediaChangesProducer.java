package com.tarun.springboot;


import java.util.concurrent.TimeUnit;

@Service
public class WikiMediaChangesProducer {
    private static final LOGGER logger = LoggerFactory.getLogger(WikiMediaChangesProducer.class);

    private kafkaTemplate<String,String> kafkaTemplate;

    public WikiMediaChangesProducer(kafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }
    // no need of autowired

    public void sendMessage() throws InterruptedException {
        String topic = "wikimedia_recent";

        //to read real time stream data from wikimedia , we use event source
        //okhttp eventsource maven
        // version maven dependancy we use // module ke pom me modeule me add kar de
        EventHandler eventHandler = new WikiMediaChangesHandler(kafkaTemplate,topic);
        String url = "";// stream wikimediaass here

        EventSource.Builder builder = new EventSource.Builder(eventHandler,URI.create(url));
        EventSource eventSource = builder.build();
        eventSource.start();
        TimeUnit.MINUTES.sleep(10);

    }

}
