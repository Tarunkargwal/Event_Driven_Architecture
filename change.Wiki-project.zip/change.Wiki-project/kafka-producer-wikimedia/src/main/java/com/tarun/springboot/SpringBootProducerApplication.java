package com.tarun.springboot;
@SpringBootApplication
public class SpringBootProducerApplication implements CommandLineRunner{
    public static void main(String[] args) {
        SpringApplication.run(SpringBootProducerApplication.class);
    }
    @Autowired
    private WikiMediaChangesProducer wikiMediaChangesProducer
    public void run(String... args) throws Exception{
        wikiMediaChangesProducer.sendMessage();
    }
}
