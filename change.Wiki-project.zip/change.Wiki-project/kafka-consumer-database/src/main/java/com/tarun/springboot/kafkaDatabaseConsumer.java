package com.tarun.springboot;
@Service
public class kafkaDatabaseConsumer {
    //add logger instance
    @KafkaListner(topic ="wikimedia_recent",groupId="mrGrp");
    public void consume(String eventMessage){
        // logger statement
        
    }
}
